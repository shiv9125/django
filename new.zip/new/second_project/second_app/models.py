from django.db import models
from django.contrib.auth.models import User, AbstractUser

# Create your models here.

class ShivModel(models.Model):
    first_name=models.CharField(max_length=255, blank=True, null=True )
    last_name=models.CharField(max_length=255, blank=True, null=True )
    name=models.CharField(max_length=255, blank=True, null=True )

    def __str__(self):
        return self.name
    
class ParthModel(models.Model):
    first_name=models.CharField(max_length=255, blank=True, null=True )
    last_name=models.CharField(max_length=255, blank=True, null=True )
    name=models.CharField(max_length=255, blank=True, null=True )

    def __str__(self):
        return self.name
    

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField("date published")

class Choice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

class employee(models.Model):
    employee_name=models.CharField(max_length=255,blank=True,null=True)
    employee_id=models.IntegerField(blank=True,null=False)
    employee_salary=models.IntegerField(blank=True,null=True)
    employee_bonus=models.IntegerField(blank=True,null=True)

    def __str__(self):
        return self.employee_name
    
class BookModel(models.Model):     
    name = models.CharField(max_length=255)
    author = models.ForeignKey(User, on_delete = models.CASCADE)
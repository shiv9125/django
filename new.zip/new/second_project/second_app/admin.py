from django.contrib import admin
from .models import ShivModel, ParthModel,Question,Choice,employee
# Register your models here.

admin.site.register(ShivModel)
admin.site.register(ParthModel)
admin.site.register(Question)
admin.site.register(Choice)
admin.site.register(employee)
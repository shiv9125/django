from django.shortcuts import render
from django.http import HttpResponse
from .models import Member
# Create your views here.

# def index(request):
#     return HttpResponse("hello shiv")

def sign_up(request):
    # print(request.POST,'---------------')
    return render(request,'signup.html')


def detail(request):
    member_list = Member.objects.all().values()
    context = {'member_list': member_list}
    # print(context, '------------content-----------')
    return render(request,"display.html",context)

def user_data(request,id):
    my_data = Member.objects.get(id=id)
    context = {'my_data':my_data}
    return render(request,"user_data.html",context)

def main(request):
    return render(request,'main.html')    

def testing(request):
    context = {'fruits': ['Apple', 'Banana', 'Cherry'],} 
    return render(request,'template.html',context)

def all_data(request):
    data = Member.objects.all().values()
    # my_data_list=[]
    # for x in data:
    #     my_data_list.append(x['firstname'])
    # context = {'my_data': my_data_list}
    context={'my_data':data}
    return render(request, 'data.html', context)

    

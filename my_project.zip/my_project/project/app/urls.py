from django.urls import path
from . import views

urlpatterns = [
    path('main/', views.main, name='main'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('main/detail/', views.detail, name='detail'),
    path('main/detail/student/<int:id>/', views.user_data, name='user_data'),
    path('testing/', views.testing, name='testing'),
    path('data/', views.all_data, name='data'),

]
from django.db import models

# Create your models here.
  
class Member(models.Model):

    reg_no = models.IntegerField()
    firstname = models.CharField(max_length=255,blank=True,null=True)
    lastname = models.CharField(max_length=255,blank=True,null=True)
    fullname = models.CharField(max_length=255,blank=True,null=True)
    salary = models.IntegerField()
    phone = models.IntegerField(null=True)
    joined_date = models.DateField(null=True)

    def __str__(self):
        return str(self.fullname)
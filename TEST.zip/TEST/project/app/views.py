from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect,Http404
from django.urls import reverse
from django.views.generic import TemplateView
from .models import User,Car
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login, logout

# Create your views here.

class LoginView(TemplateView):
    template_name='login.html'
    def post(self,request):
        try:
            username = request.POST["username"]
            entered_password = request.POST["password"]
            user = User.objects.get(username = username)
            verify_password = check_password(entered_password, user.password)
            if verify_password:
                login(request, user)
            else:
                return HttpResponse("invalid username or password")    
            return HttpResponseRedirect(reverse("home"))
        
        except Exception as e:
            # print(e,"====================")
            return HttpResponse(str(e))

class SignUpView(TemplateView):
    template_name='signup.html'
    def post(self,request):
        # print(request.POST, '-------')
        data = User.objects.create(
            username = request.POST["username"],
            email = request.POST["email"],
            )
        data.set_password(request.POST["password"])  
        data.save()
        return HttpResponseRedirect(reverse('login'))


class AddView(TemplateView):
    template_name='addnew.html'
    def post(self, request, *args, **kwargs):
        # Retrieve data from the form submission
        serial_no = request.POST.get('serial_no')
        car_name = request.POST.get('car_name')
        price = request.POST.get('price')
        discount = request.POST.get('discount')
        coupon = request.POST.get('coupon')
        
        # Check if discount is negative and handle it
        if discount:
            try:
                discount = int(discount)
                if discount < 0:
                    discount = 0
            except ValueError:
                discount = 0
        else:
            discount = 0

        # Create a new Car object
        new_car = Car.objects.create(
            serial_no=serial_no,
            car_name=car_name,
            price=price,
            discount_percent=discount,
            coupon=coupon
        )
        # Redirect to a success page or any desired page
        return HttpResponseRedirect(reverse('home'))
    

    
class HomeView(TemplateView):
    template_name='home.html'
    def get(self,request):
         data= Car.objects.all()
         context= {'my_data':data}
         return render(request,self.template_name,context)

class EditView(TemplateView):
    template_name = 'edit.html'

    def get(self, request, id):
        car = Car.objects.get(id=id)
        context = {'car': car}
        return render(request, self.template_name, context)
    
    def post(self,request,id):
       car = Car.objects.get(id=id)
       discount = request.POST.get('discount')
       if int((discount)) < 0:
            discount=0
  
       car.serial_no = request.POST.get("serial_no", car.serial_no)
       car.car_name = request.POST.get("car_name", car.car_name)
       car.price = request.POST.get("price", car.price)
       car.discount_percent = discount
       car.coupon = request.POST.get('coupon', car.coupon)
       car.save()
       return HttpResponseRedirect(reverse("home"))
    

class DeleteView(TemplateView):
    template_name = 'edit.html'
    def get(self, request, id):
        movie = Car.objects.get(id=id)
        movie.delete()
        return HttpResponseRedirect(reverse("home"))    
        


class BillingView(TemplateView):
    template_name = 'billing.html'

    def get(self, request):
        selected_item_id = request.GET.get('car_checkbox')  
        selected_item = Car.objects.get(id=selected_item_id)
        context = {"item": selected_item, "Amount": selected_item.price}
        return render(request, self.template_name, context)

   
class MatchingView(TemplateView):
      template_name='newbilling.html'
      def get(self, request, id):
    
        discount = request.GET.get('discount')
        selected_item = Car.objects.get(id=id)
        dis=selected_item.discount_percent
        
        if dis>100:
            dis=0
        else:
            dis=selected_item.discount_percent    
       

        discount = (selected_item.price * dis) / 100
        final_amount = selected_item.price - discount

        context = {"item": selected_item, "Amount": final_amount}
        return render(request, self.template_name, context)

    
class FinalView(TemplateView):
    template_name='finalbooking.html'
    def get(self,request):
        return render(request,self.template_name)


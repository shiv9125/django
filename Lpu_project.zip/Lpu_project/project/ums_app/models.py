from django.db import models

# Create your models here.
class Student(models.Model):
    Registration_no = models.IntegerField(unique = True)
    Name = models.CharField(max_length=255,blank=True,null=True)
    Date_of_birth = models.DateField(blank=True,null=True)
    Gender = models.CharField(max_length=255,blank=True,null=True)
    Program = models.CharField(max_length=255,blank=True,null=True)
    FatherName = models.CharField(max_length=255,blank=True,null=True)
    MotherName = models.CharField(max_length=255,blank=True,null=True)
    Phone = models.IntegerField()
    Email = models.EmailField()
    password = models.CharField(max_length=255,blank=True,null=True)
    

    def __str__(self):
        return str(self.Registration_no)

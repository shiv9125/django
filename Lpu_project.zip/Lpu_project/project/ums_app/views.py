from django.shortcuts import render
from django.views.generic import TemplateView
from .models import Student
from django.urls import reverse
from  django.http import HttpResponse,HttpResponseRedirect
# Create your views here.

class Sign_up(TemplateView):
    template_name = 'sign_up.html'
    def get(self,request):
        return render(request,self.template_name)
    def post(self,request):
           student = Student.objects.create(Registration_no = request.POST['registrationNumber'], Name = request.POST['name'],
           Email = request.POST['email'],
           password = request.POST['password'],
           Phone = request.POST['phone']),
           return HttpResponse("record added successfully !")

class home(TemplateView):
      template_name='home.html'
      def get(self,request):
           return render(request,self.template_name) 
      

class Lpu(TemplateView):
    template_name = "login.html"
    def get(self, request):
        return render(request, self.template_name)
    
    def post(self,request):
        Registration_no = request.POST.get("registrationNumber")
        password = request.POST.get("password")
        
        my_data = Student.objects.filter(Registration_no=Registration_no , password=password)
        context={'my_data':my_data}
        return HttpResponseRedirect(reverse("home"))
    
class profile(TemplateView):
    #  template_name='student_detail.html'
     def get(self,request):
         my_data = Student.objects.get(Registration_no=12009841)
         print(my_data,'--------0----------0-----------------')
         context = {'my_data':my_data}
         return render(request,'student_detail.html',context)
    
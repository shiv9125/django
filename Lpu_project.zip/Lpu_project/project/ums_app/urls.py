from django.urls import path
from .views import Lpu,Sign_up,home,profile
# from .views import Lpu

urlpatterns = [
    path('login/', Lpu.as_view(), name='login'),
    path('sign_up/', Sign_up.as_view(), name='sign_up'),
    path('home/',home.as_view(),name='home'),
    path('profile/',profile.as_view(),name='profile')
]
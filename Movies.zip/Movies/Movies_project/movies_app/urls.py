from django.urls import path
from .views import LoginView,SignUpView,HomeView,BillingView,HistoryView,AddView,EditView,DeleteView

urlpatterns = [

    path('login/', LoginView.as_view(), name='login'),
    path('signup/', SignUpView.as_view(), name='signup'),
    path('home/', HomeView.as_view(), name='home'),
    path('addnew/', AddView.as_view(), name='addnew'),
    path('edit/<int:id>/', EditView.as_view(), name='edit'),
    path('delete/<int:id>/', DeleteView.as_view(), name='delete'),
    path('billing/', BillingView.as_view(), name='billing'),
    path('history/<int:id>/', HistoryView.as_view(), name='history'),

]
      


from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from django.views.generic import TemplateView
from .models import Movie,User,History
from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login, logout

# Create your views here.

class LoginView(TemplateView):
    template_name='login.html'
    def post(self,request):
        try:
            username = request.POST["username"]
            entered_password = request.POST["password"]
            user = User.objects.get(username = username)
            verify_password = check_password(entered_password, user.password)
            if verify_password:
                login(request, user)
            else:
                return HttpResponse("invalid username or password")    
            return HttpResponseRedirect(reverse("home"))
        
        except Exception as e:
            # print(e,"====================")
            return HttpResponse(str(e))

class SignUpView(TemplateView):
    template_name='signup.html'
    def post(self,request):
        # print(request.POST, '-------')
        data = User.objects.create(
            username = request.POST["username"],
            email = request.POST["email"],
            )
        data.set_password(request.POST["password"])  
        data.save()
        return HttpResponseRedirect(reverse('login'))
    
    
class HomeView(TemplateView):
    template_name='home.html'
    def get(self,request):
        data= Movie.objects.all()
        context= {'my_data':data}
        return render(request,self.template_name,context)
    
    
class AddView(TemplateView):
    template_name='addnew.html'
    def post(self, request, *args, **kwargs):
        # Retrieve data from the form submission
        new_movie = Movie.objects.create(
          serial_no = request.POST['serial_no'],
          movie_name = request.POST['movie_name'],
          genre = request.POST['genre'],
          price = request.POST['price'],
          )
        # Redirect to a success page or any desired page
        return HttpResponseRedirect(reverse('home'))


class EditView(TemplateView):
    template_name = 'edit.html'

    def get(self, request, id):
        movie = Movie.objects.get(id=id)
        context = {'movie': movie}
        return render(request, self.template_name, context)
    
    def post(self,request,id):
        a= Movie.objects.get(id=id)
        print(a, '-------detais-----------')
        a.serial_no  = request.POST["serial_no"]
        a.movie_name = request.POST["movie_name"]
        a.genre = request.POST["genre"]
        a.price = request.POST['price']
        a.save()
        return HttpResponseRedirect(reverse("home"))
    

class DeleteView(TemplateView):
    template_name = 'edit.html'
    def get(self, request, id):
        movie = Movie.objects.get(id=id)
        movie.delete()
        return HttpResponseRedirect(reverse("home"))
    
      
class BillingView(TemplateView):
    template_name = 'billing.html'
    
    def get(self, request):
        selected_item_ids = request.GET.getlist('movie_checkbox')
        selected_items = Movie.objects.filter(id__in=selected_item_ids)
        print(selected_items,'-------------hhhhhhhhh-------------')
        total_amount=0
        for item in selected_items:
            total_amount+=item.price
        context = {"selected": selected_items, "total_amount": total_amount}
        return render(request, self.template_name, context)
        
    
    def post(self, request):
        selected_item_ids = request.GET.getlist('movie_checkbox')
        selected_items = Movie.objects.filter(id__in=selected_item_ids)
        print(selected_items,'-------------------9999999999-----9-------------')
        # Save the ticket booking information to the database
        for item in selected_items:
            History.objects.create(
                user=request.user,
                movie_name=item.movie_name,
                genre=item.genre,
                price=item.price,
                status="Booked"
            )
        return render(request, 'finalbooking.html')
    

class HistoryView(TemplateView):
    template_name = 'history.html'

    def get(self, request, id):
        transactions = History.objects.filter(user_id=id)
        # print(transactions, '---------00000000000000000===========')
        context = {"transactions": transactions}
        return render(request, self.template_name, context)